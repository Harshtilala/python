<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$sender_id = $_SESSION['user_id']; // Current logged-in user ID
$username = $_SESSION['username']; // Current logged-in username

// Create database connection
require 'db.php';
$conn = getDBConnection();

// Fetch all users for the selection dropdown
$user_query = "SELECT id, username FROM users WHERE id != ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $sender_id);
$stmt->execute();
$result = $stmt->get_result();
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
$stmt->close();
$conn->close();

// Get selected user ID from query parameter (if exists)
$selected_user_id = isset($_GET['to_user']) ? intval($_GET['to_user']) : null;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Application</title>
    <link href="https://bootswatch.com/5/pulse/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #f4f7fc;
        }
        h2 {
            color: #333;
        }
        #chatBox {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            height: 300px;
            overflow-y: auto;
            padding: 10px;
            margin-bottom: 20px;
        }
        #message {
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        #send-button {
            background-color: #0d6efd;
            border-color: #0d6efd;
            color: white;
        }
        #send-button:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        footer {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Welcome, <?php echo htmlspecialchars($username); ?>!</h2>

        <!-- User selection dropdown -->
        <div class="mb-3">
            <label for="userSelect">Select User to Chat:</label>
            <select id="userSelect" class="form-control" onchange="location.href=this.value;">
                <option value="">-- Select User --</option>
                <?php foreach ($users as $user): ?>
                    <option value="chat.php?to_user=<?php echo htmlspecialchars($user['id']); ?>" 
                        <?php echo ($selected_user_id == htmlspecialchars($user['id'])) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($user['username']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div id="chatBox">
            <!-- Chat messages will load here -->
            <div id="messages"></div>
        </div>

        <form id="chatForm">
            <input type="hidden" id="to_user" name="to_user" value="<?php echo htmlspecialchars($selected_user_id); ?>">
            <div class="mb-3">
                <textarea class="form-control" id="message" name="message" placeholder="Type your message..." rows="3"></textarea>
            </div>
            <input type="submit" id="send-button" class="btn btn-primary" value="Send">
        </form>

        <center>
            <br>
            <h2><a href="logout.php">Logout</a></h2>
        </center>

        <footer class="text-center">
            <p>&copy; <?php echo date("Y"); ?> Chat Application</p>
        </footer>
    </div>

<script>
$(document).ready(function() {
    const selectedUserId = $('#to_user').val();

    // Function to load messages for the selected user
    function loadMessages() {
        $.ajax({
            url: 'fetch_messages.php?to_user=' + selectedUserId,
            method: 'GET',
            success: function(data) {
                $('#messages').html(data);
                $('#chatBox').scrollTop($('#chatBox')[0].scrollHeight);
            },
            error: function() {
                console.error("Failed to load messages.");
            }
        });
    }

    // Load messages every second
    setInterval(loadMessages, 1000);

    // Send message on form submit
    $('#chatForm').on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission

        var message = $('#message').val().trim();
        
        // Ensure that a recipient is selected before sending a message.
        if (!selectedUserId) { 
            alert("Please select a user to chat with.");
            return; 
        }

        if (message) { 
            $.ajax({
                url: 'send_message.php',
                method: 'POST',
                data: { 
                    message: message,
                    to_user: selectedUserId 
                },
                success: function(response) { 
                    $('#message').val(''); // Clear the message input 
                    loadMessages(); // Refresh messages after sending 
                },
                error: function() { 
                    alert("Failed to send message."); 
                } 
            }); 
        } else { 
            alert("Please enter a message."); 
        } 
    });

    // Load initial messages for the selected user
    loadMessages();
});
</script>

</body>
</html>
