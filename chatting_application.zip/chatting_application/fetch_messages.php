<?php
session_start();

// Database configuration
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'chat_app';

// Function to get database connection
function getDBConnection() {
    global $host, $user, $password, $db;
    $conn = new mysqli($host, $user, $password, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Handle user selection for direct messaging
$selected_user_id = isset($_GET['to_user']) ? intval($_GET['to_user']) : null;

// Create database connection
$conn = getDBConnection();

// Display all messages if no specific user is selected
if ($selected_user_id === null) {
    echo "<h2>All Messages</h2>";
    
    // Query to get all messages with usernames
    $query = "SELECT m.*, u1.username AS from_username, u2.username AS to_username 
              FROM messages m 
              JOIN users u1 ON m.from_user = u1.id 
              LEFT JOIN users u2 ON m.to_user = u2.id 
              ORDER BY m.timestamp ASC";
    $result = $conn->query($query);

    while ($row = $result->fetch_assoc()) {
        $time = date('h:i A', strtotime($row['timestamp']));
        echo '<div class="message"><strong>' . htmlspecialchars($row['from_username']) . ' (ID: ' . htmlspecialchars($row['from_user']) . '):</strong> ' . 
             htmlspecialchars($row['message']) . ' <small>(' . $time . ')</small></div>';
    }
} else {
    // Display messages between the logged-in user and the selected user
    echo "<h2>Chat with User ID: " . htmlspecialchars($selected_user_id) . "</h2>";

    // Prepare the SQL statement for direct messaging
    $message_query = "SELECT m.*, u1.username AS from_username, u2.username AS to_username 
                      FROM messages m 
                      JOIN users u1 ON m.from_user = u1.id 
                      JOIN users u2 ON m.to_user = u2.id 
                      WHERE (m.from_user = ? AND m.to_user = ?) OR (m.from_user = ? AND m.to_user = ?) 
                      ORDER BY m.timestamp ASC";

    $message_stmt = $conn->prepare($message_query);
    if ($message_stmt === false) {
        echo "<p>Error preparing statement: " . htmlspecialchars($conn->error) . "</p>";
        exit();
    }

    // Bind parameters and execute the statement
    $message_stmt->bind_param("iiii", $_SESSION['user_id'], $selected_user_id, $selected_user_id, $_SESSION['user_id']);
    $message_stmt->execute();
    
    // Get results from executed statement.
    $messages_result = $message_stmt->get_result();

    if ($messages_result === false) {
        echo "<p>Error executing query: " . htmlspecialchars($conn->error) . "</p>";
        exit();
    }

    if ($messages_result->num_rows > 0) {
        while ($msg_row = $messages_result->fetch_assoc()) {
            echo "<div><strong>" . htmlspecialchars($msg_row['from_username']) . " (ID: " . htmlspecialchars($msg_row['from_user']) . "):</strong> " . 
                 htmlspecialchars($msg_row['message']) . " <small>(" . date('h:i A', strtotime($msg_row['timestamp'])) . ")</small></div>";
            echo "<div><strong>" . htmlspecialchars($msg_row['to_username']) . " (ID: " . htmlspecialchars($msg_row['to_user']) . "):</strong> " .
                 htmlspecialchars($msg_row['message']) . " <small>(" . date('h:i A', strtotime($msg_row['timestamp'])) . ")</small></div>";
        }
    } else {
        echo "<p>No messages yet.</p>";
    }

    // Close statement for direct messages
    $message_stmt->close();
}

// Close database connection
$conn->close();
?>