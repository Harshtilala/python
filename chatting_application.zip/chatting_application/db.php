<?php
// db.php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // Change this if necessary
define('DB_PASSWORD', ''); // Change this if necessary
define('DB_NAME', 'chat_app');

function getDBConnection() {
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    return $conn;
}
?>  