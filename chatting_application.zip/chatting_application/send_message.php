<?php
session_start();

// Database configuration
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'chat_app';

// Function to get database connection
function getDBConnection() {
    global $host, $user, $password, $db;
    $conn = new mysqli($host, $user, $password, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Handle message sending
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get user details
    $from_user = $_SESSION['user_id']; // Use session user ID directly for DB operations
    $to_user = $_POST['to_user'] ?? null; // Recipient for direct messages
    $message = trim($_POST['message']);

    // Validate message and recipient
    if (empty($message)) {
        echo "Message cannot be empty!";
        exit();
    }

    try {
        // Prepare and execute the SQL statement
        $conn = getDBConnection();
        
        // Insert message into database
        if ($to_user) {
            // Direct message to specific user
            $stmt = $conn->prepare("INSERT INTO messages (from_user, to_user, message, timestamp) VALUES (?, ?, ?, NOW())");
            
            if ($stmt === false) {
                echo "Error preparing statement.";
                exit();
            }

            $stmt->bind_param("iis", $from_user, $to_user, $message);
            
            if ($stmt->execute()) {
                echo "Message sent."; // Optionally return a success message.
            } else {
                echo "Error sending message.";
            }
            
        } else {
            echo "No recipient specified.";
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();

    } catch (mysqli_sql_exception $e) {
        echo "Error: " . htmlspecialchars($e->getMessage());
    }
}
?>
